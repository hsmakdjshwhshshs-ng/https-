from flask import Flask, render_template, request, redirect, session, url_for, jsonify, send_from_directory
from flask_socketio import SocketIO, emit, join_room, leave_room
from datetime import datetime
import uuid
import os
from werkzeug.utils import secure_filename

# -------------------------
# إعداد التطبيق
# -------------------------
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret_chat_key_advanced'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB
app.config['ALLOWED_EXTENSIONS'] = {
    'png', 'jpg', 'jpeg', 'gif',
    'mp3', 'wav', 'ogg', 'webm', 'm4a'
}

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# 🔴 التعديل الحاسم هنا
socketio = SocketIO(
    app,
    cors_allowed_origins="*",
    async_mode="threading",   # ← يمنع eventlet نهائيًا
    logger=True,
    engineio_logger=True
)

# -------------------------
# بيانات وهمية
# -------------------------
USERS = {
    "حسن": "2222",
    "حوراء": "8888",
    "admin": "1234"
}

MESSAGES = []
CONNECTED_USERS = {}
USER_SIDS = {}
ACTIVE_CALLS = {}

# -------------------------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# -------------------------
# تسجيل الدخول
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        if username in USERS and USERS[username] == password:
            session['username'] = username
            session['user_id'] = str(uuid.uuid4())[:8]
            return redirect(url_for("chat"))

        return render_template("login.html", error="بيانات الدخول غير صحيحة")

    return render_template("login.html")

# -------------------------
@app.route("/logout")
def logout():
    username = session.get("username")
    if username in CONNECTED_USERS:
        del CONNECTED_USERS[username]
    session.clear()
    return redirect(url_for("login"))

# -------------------------
@app.route("/chat")
def chat():
    if "username" not in session:
        return redirect(url_for("login"))

    return render_template(
        "chat.html",
        username=session["username"],
        user_id=session["user_id"],
        messages=MESSAGES[-100:]
    )

# -------------------------
# رفع الملفات
@app.route("/upload", methods=["POST"])
def upload_file():
    if "username" not in session:
        return jsonify({"error": "غير مصرح"}), 401

    if "file" not in request.files:
        return jsonify({"error": "لا يوجد ملف"}), 400

    file = request.files["file"]

    if file.filename == "":
        return jsonify({"error": "اسم الملف فارغ"}), 400

    if file and allowed_file(file.filename):
        ext = file.filename.rsplit(".", 1)[1].lower()
        filename = secure_filename(
            f"{session['user_id']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{ext}"
        )

        path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(path)

        file_type = "image" if ext in ['png','jpg','jpeg','gif'] else "audio"

        return jsonify({
            "success": True,
            "filename": filename,
            "url": f"/static/uploads/{filename}",
            "type": file_type
        })

    return jsonify({"error": "نوع الملف غير مسموح"}), 400

# -------------------------
@app.route("/static/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# -------------------------
# SocketIO Events
# -------------------------
@socketio.on("connect")
def on_connect():
    username = session.get("username")
    if username:
        CONNECTED_USERS[username] = request.sid
        USER_SIDS[request.sid] = username
        join_room("all")

        emit("user_status", {
            "username": username,
            "status": "online"
        }, room="all")

        print(f"✅ {username} متصل")

@socketio.on("disconnect")
def on_disconnect():
    sid = request.sid
    username = USER_SIDS.get(sid)

    if username:
        CONNECTED_USERS.pop(username, None)
        USER_SIDS.pop(sid, None)

        emit("user_status", {
            "username": username,
            "status": "offline"
        }, room="all")

        print(f"❌ {username} خرج")

# -------------------------
@socketio.on("send_message")
def send_message(data):
    msg = {
        "id": str(uuid.uuid4()),
        "username": data["username"],
        "user_id": data["user_id"],
        "content": data.get("content", ""),
        "type": data.get("type", "text"),
        "timestamp": datetime.now().isoformat()
    }

    MESSAGES.append(msg)
    emit("new_message", msg, room="all")

# -------------------------
if __name__ == "__main__":
    print("🚀 تشغيل السيرفر")
    socketio.run(
        app,
        host="0.0.0.0",
        port=5000,
        debug=True,
        allow_unsafe_werkzeug=True
    )
