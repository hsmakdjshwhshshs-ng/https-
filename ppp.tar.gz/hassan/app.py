from flask import Flask, render_template, request, redirect, session, url_for, jsonify, send_from_directory
from flask_socketio import SocketIO, emit
from datetime import datetime
import uuid
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['SECRET_KEY'] = 'whatsapp_clone_secret_key_2024'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif', 'mp3', 'wav', 'ogg', 'mp4', 'webm', 'wav'}

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

messages = []
active_calls = {}
user_sessions = {}
online_users = {}

USERS = {
    "حسن": {"password": "2222", "display_name": "حسن", "avatar_color": "#25D366"},
    "حوراء": {"password": "8888", "display_name": "حوراء", "avatar_color": "#128C7E"}
}

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        if username in USERS and USERS[username]["password"] == password:
            session['username'] = username
            session['user_id'] = str(uuid.uuid4())[:8]
            session['display_name'] = USERS[username]["display_name"]
            return redirect(url_for("chat"))
    return render_template("login.html")

@app.route("/chat")
def chat():
    if "username" not in session: return redirect(url_for("login"))
    other_user = "حوراء" if session['username'] == "حسن" else "حسن"
    return render_template("chat.html",
                         username=session['username'],
                         display_name=session['display_name'],
                         user_id=session['user_id'],
                         avatar_color=USERS[session['username']]["avatar_color"],
                         other_user=other_user,
                         other_display_name=USERS[other_user]["display_name"],
                         messages=messages[-50:])

@app.route("/upload", methods=["POST"])
def upload_file():
    file = request.files.get('file')
    if not file: return jsonify({"success": False}), 400
    orig_name = file.filename if file.filename else "voice.webm"
    ext = orig_name.rsplit('.', 1)[1].lower() if '.' in orig_name else "webm"
    filename = f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    file_type = 'image' if ext in ['png', 'jpg', 'jpeg', 'gif'] else 'video' if ext in ['mp4', 'webm'] else 'audio'
    return jsonify({"success": True, "file_url": url_for('uploaded_file', filename=filename), "type": file_type})

@app.route("/static/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route("/api/messages/<message_id>", methods=["DELETE", "PUT"])
def manage_message(message_id):
    if "username" not in session: return jsonify({"error": "Unauthorized"}), 401

    for i, msg in enumerate(messages):
        if msg['id'] == message_id:
            if request.method == "DELETE":
                if msg['username'] == session['username']:
                    messages.pop(i)
                    socketio.emit('message_deleted', {'id': message_id})
                    return jsonify({"success": True})
            elif request.method == "PUT":
                if msg['username'] == session['username']:
                    data = request.json
                    new_content = data.get('content')
                    if new_content:
                        msg['content'] = new_content
                        msg['edited'] = True
                        socketio.emit('message_updated', msg)
                        return jsonify({"success": True})
    return jsonify({"success": False}), 404

@socketio.on('register')
def handle_register(data):
    username = data.get('username')
    user_sessions[username] = request.sid
    online_users[username] = True
    emit('user_status', {'username': username, 'online': True}, broadcast=True)

@socketio.on('disconnect')
def handle_disconnect():
    for user, sid in list(user_sessions.items()):
        if sid == request.sid:
            user_sessions.pop(user)
            online_users.pop(user, None)
            emit('user_status', {'username': user, 'online': False}, broadcast=True)

@socketio.on('send_message')
def handle_send_message(data):
    msg_id = str(uuid.uuid4())
    reply_data = None
    if data.get('reply_to'):
        for m in messages:
            if m['id'] == data['reply_to']:
                reply_data = {'display_name': USERS[m['username']]['display_name'], 'content': m['content'], 'type': m['type']}
                break
    message = {
        'id': msg_id, 'username': data['username'], 'display_name': USERS[data['username']]['display_name'],
        'type': data.get('type', 'text'), 'content': data.get('content', ''),
        'file_url': data.get('file_url', ''), 'reply_data': reply_data,
        'reactions': {},
        'time_display': datetime.now().strftime('%I:%M %p'),
        'edited': False
    }
    messages.append(message)
    emit('new_message', message, broadcast=True)

@socketio.on('react_message')
def handle_react_message(data):
    msg_id = data.get('message_id')
    emoji = data.get('emoji')
    username = session.get('username')
    for msg in messages:
        if msg['id'] == msg_id:
            if 'reactions' not in msg: msg['reactions'] = {}
            for e in list(msg['reactions'].keys()):
                if username in msg['reactions'][e]:
                    msg['reactions'][e].remove(username)
                    if not msg['reactions'][e]: del msg['reactions'][e]
            if emoji not in msg['reactions']: msg['reactions'][emoji] = []
            msg['reactions'][emoji].append(username)
            emit('message_reacted', {'id': msg_id, 'reactions': msg['reactions']}, broadcast=True)
            break

@socketio.on('start_call')
def handle_start_call(data):
    caller, callee = data.get('caller'), data.get('callee')
    if callee not in online_users:
        emit('call_failed', {'reason': 'المستخدم غير متصل حالياً'}, room=request.sid)
        return
    call_id = str(uuid.uuid4())[:8]
    active_calls[call_id] = {'caller': caller, 'callee': callee}
    emit('incoming_call', {'call_id': call_id, 'caller': caller, 'caller_display': USERS[caller]['display_name'], 'signal': data.get('signal')}, room=user_sessions[callee])

@socketio.on('accept_call')
def handle_accept_call(data):
    caller = data.get('caller')
    if caller in user_sessions:
        emit('call_accepted', {'call_id': data.get('call_id'), 'signal': data.get('signal')}, room=user_sessions[caller])

@socketio.on('reject_call')
def handle_reject_call(data):
    caller = data.get('caller')
    if caller in user_sessions:
        emit('call_rejected', {}, room=user_sessions[caller])

@socketio.on('end_call')
def handle_end_call(data):
    call_id = data.get('call_id')
    if call_id in active_calls:
        c = active_calls.pop(call_id)
        for u in [c['caller'], c['callee']]:
            if u in user_sessions: emit('call_ended', {}, room=user_sessions[u])

@socketio.on('webrtc_signal')
def handle_webrtc_signal(data):
    target = data.get('target')
    if target in user_sessions:
        emit('webrtc_signal', {'from': session.get('username'), 'signal': data.get('signal')}, room=user_sessions[target])

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000, debug=True)
