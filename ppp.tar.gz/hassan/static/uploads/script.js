// وظائف مساعدة إضافية للدردشة
function formatTime(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    // إذا كان نفس اليوم
    if (date.toDateString() === now.toDateString()) {
        return date.toLocaleTimeString('ar-EG', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }
    
    // إذا كان نفس الأسبوع
    if (diff < 7 * 24 * 60 * 60 * 1000) {
        return date.toLocaleDateString('ar-EG', { 
            weekday: 'long' 
        });
    }
    
    // تاريخ كامل
    return date.toLocaleDateString('ar-EG', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
}

function addDateSeparator(dateStr) {
    const separator = document.createElement('div');
    separator.className = 'date-separator';
    separator.innerHTML = `<span>${dateStr}</span>`;
    chatContainer.appendChild(separator);
}

function openMedia(url) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.9);
        z-index: 2000;
        display: flex;
        align-items: center;
        justify-content: center;
    `;
    
    const img = document.createElement('img');
    img.src = url;
    img.style.maxWidth = '90%';
    img.style.maxHeight = '90%';
    img.style.borderRadius = '10px';
    
    const closeBtn = document.createElement('button');
    closeBtn.innerHTML = '<i class="fas fa-times"></i>';
    closeBtn.style.cssText = `
        position: absolute;
        top: 20px;
        left: 20px;
        background: none;
        border: none;
        color: white;
        font-size: 30px;
        cursor: pointer;
    `;
    
    modal.appendChild(img);
    modal.appendChild(closeBtn);
    document.body.appendChild(modal);
    
    closeBtn.addEventListener('click', () => {
        document.body.removeChild(modal);
    });
    
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            document.body.removeChild(modal);
        }
    });
}

// دالة للبحث في المحادثة
function searchMessages(query) {
    const messages = document.querySelectorAll('.message');
    messages.forEach(msg => {
        const text = msg.textContent.toLowerCase();
        if (text.includes(query.toLowerCase())) {
            msg.style.backgroundColor = 'rgba(255, 255, 0, 0.3)';
            msg.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
            msg.style.backgroundColor = '';
        }
    });
}

// دالة لحفظ الرسائل محلياً (للمستخدم الحالي فقط)
function saveMessageLocally(msg) {
    const savedMessages = JSON.parse(localStorage.getItem('chatMessages') || '[]');
    savedMessages.push({
        ...msg,
        savedAt: new Date().toISOString()
    });
    localStorage.setItem('chatMessages', JSON.stringify(savedMessages.slice(-100)));
}

// تحسينات للواجهة على الهواتف
function isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

if (isMobile()) {
    document.addEventListener('touchstart', function() {}, {passive: true});
    
    // تحسين تجربة الإدخال على الهواتف
    messageInput.addEventListener('focus', function() {
        setTimeout(() => {
            document.body.scrollTop = document.body.scrollHeight;
        }, 300);
    });
}

// تهيئة المتغيرات عند تحميل الصفحة
window.addEventListener('load', function() {
    // إضافة تأثيرات للواجهة
    const style = document.createElement('style');
    style.textContent = `
        .date-separator {
            text-align: center;
            margin: 20px 0;
            position: relative;
        }
        
        .date-separator span {
            background: #e0e0e0;
            padding: 5px 15px;
            border-radius: 15px;
            font-size: 12px;
            color: #666;
        }
        
        .typing-indicator {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #666;
            font-size: 12px;
            margin-right: 10px;
        }
        
        .typing-dots {
            display: flex;
            gap: 3px;
        }
        
        .typing-dots span {
            width: 5px;
            height: 5px;
            background: #666;
            border-radius: 50%;
            animation: typing 1.4s infinite;
        }
        
        .typing-dots span:nth-child(2) {
            animation-delay: 0.2s;
        }
        
        .typing-dots span:nth-child(3) {
            animation-delay: 0.4s;
        }
        
        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-5px); }
        }
    `;
    document.head.appendChild(style);
});
