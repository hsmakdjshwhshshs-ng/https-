// تحسين التمرير إلى الأسفل
function scrollToBottom() {
    const chatContainer = document.getElementById('chatContainer');
    if (chatContainer) {
        // استخدم طرق مختلفة للتمرير السلس
        chatContainer.scrollTop = chatContainer.scrollHeight;
        
        // بديل للتمرير السلس
        setTimeout(() => {
            chatContainer.scrollTo({
                top: chatContainer.scrollHeight,
                behavior: 'smooth'
            });
        }, 100);
    }
}

// إصلاح مشكلة التمرير عند إضافة رسائل
function displayMessage(msg) {
    // ... كود عرض الرسالة ...
    
    // بعد إضافة الرسالة، قم بالتمرير بعد فترة قصيرة
    setTimeout(scrollToBottom, 50);
}

// إضافة مستمع للتمرير لتحسين الأداء
document.addEventListener('DOMContentLoaded', () => {
    const chatContainer = document.getElementById('chatContainer');
    
    if (chatContainer) {
        // تحسين أداء التمرير
        chatContainer.style.willChange = 'transform';
        
        // إعادة تعيين will-change بعد التمرير
        chatContainer.addEventListener('scroll', () => {
            chatContainer.style.willChange = 'transform';
        });
        
        // التمرير إلى الأسفل عند التحميل
        setTimeout(scrollToBottom, 100);
    }
});
